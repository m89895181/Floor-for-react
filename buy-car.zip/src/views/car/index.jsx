import React, { Component } from 'react'
import Footer from '@/components/footer/footer'
import Header from '@/components/header/header'

class Car extends Component {
    render() {
        return (
            <div>
                Car
                <Footer></Footer>
            </div>
        )
    }
}
export default Car