import React, { Component } from 'react'

class Detail extends Component {
    render() {
        return (
            <div>
                Detail
            </div>
        )
    }
}
export default Detail